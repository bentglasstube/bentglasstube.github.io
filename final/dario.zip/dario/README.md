Dr Dario DDS
============

This is my entry for Ludum Dare 32 - Theme: Unconventional weapons.

You are Dr Dario, DDS.  Recently out of dental school and very much in debt you
have nefariously decided to ruin everyone's teeth with candies.  Stack up four
of the same color candies in a row or column to clear them and rot the teeth
nearby.  You lose if the mouth gets too full.  You win if you can get a hole
all the way through a tooth.

### Controls ###

Left/Right/A/D - Move candy
Up/Q/W/E       - Rotate candy
Down/S         - Fast drop candy
Space          - Pause
R              - Restart (only when not playing)
Escape         - Quit

### Disclaimer ###

This is a VERY EARLY release of the game.  It looks like garbage and it's hard
to tell what the fuck is going on.  You have been warned.
