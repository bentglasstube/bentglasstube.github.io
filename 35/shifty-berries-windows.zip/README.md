# Ludum Dare 35 - Shifty Berries

Use berries to shapeshift into different animals and navigate through platform
puzzles.  Each animal has strengths and weaknesses.

## Controls

 * A - Move Left
 * D - Move Right
 * Space - Jump
 * J - Eat berries

## Building, running, installing

You will need SDL2 and SDL2_mixer to build (and run on linux).
