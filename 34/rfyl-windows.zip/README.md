# Penguin

You are a penguin.

Avoid the rocks.  Collect the fish.

A to run left, D to run right.
